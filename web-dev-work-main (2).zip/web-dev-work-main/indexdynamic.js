// for main
const MainIndex = document.createElement('section');

MainIndex.innerHTML = `
    
<section class="container">   
    
           
        
      
        
<main class="box1">
    
    <h2>What is the NLSAC</h2>
    <p>xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</p>
    <h3>Why is the NLSAC is important?</h3>
    <ul class="">
        <li>xxxx</li>
        <li>xxxx</li>
        <li>xxxx</li>
        <li>xxxx</li>
    </ul>
<section>
    <article class="service">
            <h3>Title</h3>
            <p>xxxxxxxx</p>
    </article>

    <article class="service">
        <h3>Title</h3>
        <p>xxxxxxxxxxxx</p>
    </article>
    <p><button class="btn">Sign Up/Login</button></p>


</main>


</section>
<Footer><p>Copyright ©2022 Norwich Local Sustainability Advsiory Comitee <a href="mailto:pbv23ueu@uea.ac.uk">NLSAC</a></p></Footer>
`
const MainLoading = document.querySelector("body")
MainLoading.appendChild(MainIndex)




